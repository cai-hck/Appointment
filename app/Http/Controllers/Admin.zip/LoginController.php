<?php

namespace App\Http\Controllers;

use Auth;
use App\User;
use App\Mission;
use App\Consultant;
use App\Secretary;


use Illuminate\Support\Facades\Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;



class LoginController extends Controller
{

    public function __construtor() 
    {
        $user = Auth::user();

        if ($user) {
            if ($user->role == 'admin')  return redirect('/admin/dashboard');
            if ($user->role == 'consul') return redirect('/consul/dashboard');
            if ($user->role == 'secret') return redirect('/secret/dashboard');
        }
    }

    public function index() {
        $user = Auth::user();
        if ($user) {
            if ($user->role == 'admin')  return redirect('/admin/dashboard');
            if ($user->role == 'consul') return redirect('/consul/dashboard');
            if ($user->role == 'secret') return redirect('/secret/dashboard');
        }

        //$missions = Mission::where('status', true)->get();
        $missions = Mission::select('missions.*')->leftjoin('consultants','consultants.id','=','missions.consultant_id')
                ->where('consultants.status', true)
                ->where('missions.status', true)->get();
        return view('welcome',compact('missions'));
    }
    public function showLoginPage()
    {     
        if (Auth::check())
        {
            $user = Auth::user();
            if ($user->role == 'admin')
            {
                return redirect('admin/dashboard');
            }
            if ($user->type == 'consul')
            {
                
            }   
            if ($user->role == 'secret')
            {
                
            }     
        }        
        return view('login');
    }

    public function logout()
    {
        Auth::logout();
        return redirect('login');
    }

    public function login_action(Request $request)
    {
        $uname = $request->input('username');
        $password = $request->input('password');
            
        if (Auth::attempt(['name' => $uname, 'password' => $password]))
        {
            $user = Auth::user();          
            if ($user->role == 'admin') {
                return redirect('admin/dashboard');
            }
            if ($user->role == 'consul') {
                return redirect('consul/dashboard');
            }
            if ($user->role == 'secret') {
                return redirect('secret/dashboard');
            }
        }
        else
        {
            return redirect('/login')->with('error',__('Invalid Username or Password !'));
        }
    }


}
?>